Navodila za zagon, ostala navodila so vidna po zagonu odjemalca.

1)Ukazi v CMD-ju za zagon streznika

javac -cp "json-simple-1.1.1.jar" ChatServer.java
java -cp "json-simple-1.1.1.jar;." ChatServer


2)Ukazi v novem zavihku CMD-ja za zagon odjemalca

javac -cp "json-simple-1.1.1.jar" ChatClient.java
java -cp "json-simple-1.1.1.jar;." ChatClient

2. tocko ponavljajte, za vecje stevilo uporabnikov