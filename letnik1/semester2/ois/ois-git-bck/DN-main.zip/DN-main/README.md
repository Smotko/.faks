# OIS 2023/2024

## Domača naloga

Navodila so na voljo v [skripti](https://teaching.lavbic.net/OIS/2023-2024/DN.html).
