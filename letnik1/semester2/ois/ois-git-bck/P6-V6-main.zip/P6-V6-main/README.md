# P6 → V6 Seja, košarica, XML in e-SLOG

V pripravah na vaje **V6** bomo **implementirali nakupovalno košarico** in **pripravili e-Račun** ter spoznali naslednje koncepte:

- globalne spremenljivke vs. seja,
- nakupovanje pesmi iz seznama 100 najbolje prodajanih s pomočjo nakupovalne košarice,
- izpis e-Računa po standardu [e-SLOG](https://www.epos.si/eslog/) iz nakupovalne košarice v seji.
