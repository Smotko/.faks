if (!process.env.PORT) process.env.PORT = 8080;

// Priprava povezave na podatkovno bazo
const sqlite3 = require("sqlite3").verbose();
const pb = new sqlite3.Database("Chinook.sl3");

// Priprava strežnika
const express = require("express");
const streznik = express();
streznik.set("view engine", "hbs");
streznik.use(express.static("public"));

// Podpora sejam na strežniku
const expressSession = require("express-session");
streznik.use(
  expressSession({
    // Skrivni ključ za podpisovanje piškotov
    secret: "123456789QWERTY",
    // Novo sejo shranimo
    saveUninitialized: true,
    // Ne zahtevamo ponovnega shranjevanja
    resave: false,
    cookie: {
      // Seja poteče po 1 h neaktivnosti
      maxAge: 3600000,
    },
  })
);

const razmerje_USD_EUR = 0.84;

// Prikaz seznama pesmi na strani
streznik.get("/", (zahteva, odgovor) => {
  pb.all(
    "SELECT   Track.TrackId AS id, \
              TRACK.Name AS pesem, \
              Artist.Name AS izvajalec, \
              ROUND(Track.UnitPrice * " +
      razmerje_USD_EUR +
      ", 2) AS cena, \
              COUNT(InvoiceLine.InvoiceId) AS steviloProdaj \
     FROM     Track, Album, Artist, InvoiceLine \
     WHERE    Track.AlbumId = Album.AlbumId AND \
              Artist.ArtistId = Album.ArtistId AND \
              InvoiceLine.TrackId = Track.TrackId \
     GROUP BY Track.TrackId \
     ORDER BY steviloProdaj DESC, pesem ASC \
     LIMIT    100",
    (napaka, vrstice) => {
      if (napaka) odgovor.sendStatus(500);
      else odgovor.render("seznam", { seznamPesmi: vrstice });
    }
  );
});

// Dodajanje oz. brisanje pesmi iz košarice
streznik.get("/kosarica/:idPesmi", (zahteva, odgovor) => {
  let idPesmi = parseInt(zahteva.params.idPesmi);
  if (!zahteva.session.kosarica) zahteva.session.kosarica = [];
  if (zahteva.session.kosarica.indexOf(idPesmi) > -1) {
    // Če je pesem v košarici, jo izbrišemo
    zahteva.session.kosarica.splice(
      zahteva.session.kosarica.indexOf(idPesmi),
      1
    );
  } else {
    // Če pesmi ni v košarici, jo dodamo
    zahteva.session.kosarica.push(idPesmi);
  }
  // V odgovoru vrnemo vsebino celotne košarice
  odgovor.send(zahteva.session.kosarica);
});

// Vrni podrobnosti pesmi v košarici iz podatkovne baze
const pesmiIzKosarice = (zahteva, povratniKlic) => {
  // Če je košarica prazna
  if (!zahteva.session.kosarica || zahteva.session.kosarica.length == 0) {
    povratniKlic([]);
  } else {
    // Sicer dostopaj do podatkovne baze in pridobi podrobnosti
    pb.all(
      "SELECT Track.TrackId AS stevilkaArtikla, \
              1 AS kolicina, \
              Track.Name || ' (' || Artist.Name || ')' AS opisArtikla, \
              ROUND(Track.UnitPrice * " +
        razmerje_USD_EUR +
        ", 2) AS cena, \
              0 AS popust \
       FROM   Track, Album, Artist \
       WHERE  Track.AlbumId = Album.AlbumId AND \
              Artist.ArtistId = Album.ArtistId AND \
              Track.TrackId IN (" +
        zahteva.session.kosarica.join(",") +
        ")",
      (napaka, vrstice) => {
        if (napaka) povratniKlic(false);
        else povratniKlic(vrstice);
      }
    );
  }
};

// Podrobnosti košarice
streznik.get("/kosarica", (zahteva, odgovor) => {
  pesmiIzKosarice(zahteva, (pesmi) => {
    if (!pesmi) odgovor.sendStatus(500);
    else odgovor.send(pesmi);
  });
});

// Izpis računa v HTML predstavitvi ali izvorni XML obliki
streznik.get("/izpisiRacun/:oblika", (zahteva, odgovor) => {
  pesmiIzKosarice(zahteva, (pesmi) => {
    if (!pesmi) {
      odgovor.sendStatus(500);
    } else if (pesmi.length == 0) {
      odgovor.send(
        "<p>V košarici nimate nobene pesmi, zato računa ni mogoče pripraviti!</p>"
      );
    } else {
      let povzetek = {
        vsotaSPopustiInDavki: 0,
        vsotaZneskovDdv: 0,
        vsotaOsnovZaDdv: 0,
        vsotaVrednosti: 0,
        vsotaPopustov: 0,
      };

      pesmi.forEach(function (pesem, i) {
        pesem.zapSt = i + 1;
        pesem.vrednost = pesem.kolicina * pesem.cena;
        pesem.davcnaStopnja = 22;
        pesem.popustStopnja = pesem.popust;
        pesem.popust =
          pesem.kolicina * pesem.cena * (pesem.popustStopnja / 100);
        pesem.osnovaZaDdv = pesem.vrednost - pesem.popust;
        pesem.ddv = pesem.osnovaZaDdv * (pesem.davcnaStopnja / 100);
        pesem.osnovaZaDdvInDdv = pesem.osnovaZaDdv + pesem.ddv;

        povzetek.vsotaSPopustiInDavki += pesem.osnovaZaDdv + pesem.ddv;
        povzetek.vsotaZneskovDdv += pesem.ddv;
        povzetek.vsotaOsnovZaDdv += pesem.osnovaZaDdv;
        povzetek.vsotaVrednosti += pesem.vrednost;
        povzetek.vsotaPopustov += pesem.popust;
      });

      odgovor.setHeader("Content-Type", "text/xml");
      odgovor.render("eslog", {
        vizualiziraj: zahteva.params.oblika == "html",
        postavkeRacuna: pesmi,
        povzetekRacuna: povzetek,
      });
    }
  });
});

// Privzeto izpiši račun v HTML obliki
streznik.get("/izpisiRacun", (zahteva, odgovor) => {
  odgovor.redirect("/izpisiRacun/html");
});

streznik.listen(process.env.PORT, () => {
  console.log("Strežnik je pognan!");
});
