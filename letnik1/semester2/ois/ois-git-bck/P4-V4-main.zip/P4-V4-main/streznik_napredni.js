/**
 * Če so vrata strežnika opredeljena v okoljski spremenljivki PORT,
 * uporabimo to vrednost, sicer nastavimo vrata na vrednost 8080.
 */
const port = process.env.PORT || 8080;

// Opredelimo knjižnice, ki jih potrebujemo
const mime = require("mime-types");
const formidable = require("formidable");
const http = require("http");
const fs = require("fs");
const path = require("path");

let predpomnilnik = {};

// Kreiramo objekt strežnika in mu nastavimo osnovne parametre
const streznik = http.createServer((zahteva, odgovor) => {
  let potDoDatoteke = false;
  if (zahteva.url == "/") {
    potDoDatoteke = "./public/index.html";
  } else if (zahteva.url == "/posredujSporocilo") {
    obdelajSporocilo(zahteva, odgovor);
  } else {
    potDoDatoteke = "./public" + zahteva.url;
  }
  // Statično vsebino postrežemo le takrat, ko gre za zahtevo takšne vrste
  if (potDoDatoteke) posredujStaticnoVsebino(odgovor, potDoDatoteke);
});

// Na tej točki strežnik poženemo
streznik.listen(port, () => {
  console.log("Strežnik pognan!");
});

// Metoda za posredovanje statične vsebine (datoteke iz mape public)
function posredujStaticnoVsebino(odgovor, potDoDatoteke) {
  // Preverjanje, ali je datoteka v predpomnilniku
  if (predpomnilnik[potDoDatoteke]) {
    posredujDatoteko(odgovor, potDoDatoteke, predpomnilnik[potDoDatoteke]);
  } else {
    fs.access(potDoDatoteke, (napaka) => {
      if (!napaka) {
        fs.readFile(potDoDatoteke, (napaka, datotekaVsebina) => {
          if (napaka) {
            posredujNapako(odgovor, 500);
          } else {
            // Shranjevanje vsebine nove datoteke v predpomnilnik
            predpomnilnik[potDoDatoteke] = datotekaVsebina;
            posredujDatoteko(odgovor, potDoDatoteke, datotekaVsebina);
          }
        });
      } else {
        posredujNapako(odgovor, 404);
      }
    });
  }
}

// Obvladovanje napak
function posredujNapako(odgovor, tip) {
  odgovor.writeHead(tip, { "Content-Type": "text/plain" });
  if (tip == 404) {
    odgovor.end("Napaka 404: Vira ni mogoče najti.");
  } else if (tip == 500) {
    odgovor.end("Napaka 500: Prišlo je do napake strežnika.");
  } else {
    odgovor.end("Napaka " + tip + ": Neka druga napaka");
  }
}

// Metoda, ki vrne datoteko in nastavi tip datoteke,
// da jo brskalnik zna ustrezno prikazati
function posredujDatoteko(odgovor, datotekaPot, datotekaVsebina) {
  odgovor.writeHead(200, {
    "Content-Type": mime.lookup(path.basename(datotekaPot)),
  });
  odgovor.end(datotekaVsebina);
}

// Metoda, ki obdela sporočilo na strežniku
function obdelajSporocilo(zahteva, odgovor) {
  let obrazec = new formidable.IncomingForm();
  obrazec.parse(zahteva, (napaka, vrednosti) => {
    if (napaka) {
      posredujNapako(odgovor, 404);
    } else {
      let sporociloUporabnika =
        new Date().toJSON() +
        "|" +
        vrednosti.oseba +
        "|" +
        vrednosti.komentar +
        "|" +
        vrednosti.strah +
        "\n";
      fs.appendFile("./sporocila.txt", sporociloUporabnika, (napaka) => {
        if (napaka) {
          posredujNapako(odgovor, 500);
        } else {
          posredujZahvaloZaPosredovanKomentar(odgovor);
        }
      });
    }
  });
}

// Metoda, ki se zahvali uporabniku
function posredujZahvaloZaPosredovanKomentar(odgovor) {
  odgovor.writeHead(200, { "Content-Type": "text/plain" });
  odgovor.end("Hvala za posredovane komentarje!");
}
