/**
 * Če so vrata strežnika opredeljena v okoljski spremenljivki PORT,
 * uporabimo to vrednost, sicer nastavimo vrata na vrednost 8080.
 */
const port = process.env.PORT || 8080;

const http = require("http");
let steviloUporabnikov = 0;
http
  .createServer(function (zahteva, odgovor) {
    steviloUporabnikov++;
    odgovor.writeHead(200, { "Content-Type": "text/plain" });
    odgovor.end(
      "Pozdravljen " + steviloUporabnikov + ". ljubitelj predmeta OIS!\n"
    );
  })
  .listen(port);

console.log("Strežnik je pognan!");
